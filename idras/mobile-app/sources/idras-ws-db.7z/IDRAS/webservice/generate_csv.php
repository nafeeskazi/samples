<?php
error_reporting(0);
include("../config/class.database.php");   
include_once "header_access.php";
//http://cryptopayglobal.com/webservice/generate_csv.php
$db = new Database;
$count='1';

// open the file "locations_csv.csv" for writing
$file = fopen("locations.csv","w");

// save the column headers
fputcsv($file, array('SL','ID','X VALUE','Y VALUE'));


echo 'PdId,X,Y,Locations<br>';
$query = "select * from locations";
$db->query($query);
while($db->nextRecord())
{
	$id=$db->Record['id'];
	$x_value=$db->Record['x_value'];
	$y_value=$db->Record['y_value'];
	
fputcsv($file,array($count++,$id,$x_value,$y_value));

	$result[]  =  array(  $id,$x_value,$y_value );
?>
<?php	
	echo $id.','.$x_value.','.$y_value.',"('.$y_value.','.$x_value.')"'.'<br>';


}

// Close the file
fclose($file);

//echo '{"status" : "success",  "Locations": '.json_encode($result).' }' ;

?>