<?php 
//error_reporting(0);
include("../config/class.database.php");   
include_once "header_access.php";
//http://cryptopayglobal.com/webservice/store_co_ordinates.php

 $data = json_decode(file_get_contents('php://input'));
	
	 //$d='(8.892415999999999, 76.60421120000001)';
	 //$XYvalues = trim($d, '()');
	 $XYvalues = trim($data->{'x_y_value'}, '()');
	 $XYvalues = explode(",",$XYvalues);
	 $x_value = $XYvalues[1];
	 $y_value = $XYvalues[0];
	//$x_value = 'Test x';
	//$y_value = 'Test y';
	 
	/* $file_contents1 = file_get_contents('locations.txt', true);
	 $file_contents2 = explode(",", $file_contents1);
	 $itemCount=count($file_contents2);
	 $lastItemPosition=$itemCount - 2;
	 $id_from_txtfile=$file_contents2[$lastItemPosition];
	 if($id_from_txtfile!="")
	 {
		 $id=$id_from_txtfile + 1;
	 }
	 else
	 {
		 $id="1";
	 }*/
	 	$db2=new Database;
	    $select2="select max(id) as lastid from locations";
	    $db2->query($select2);
		$db2->singleRecord();
		$id=$db2->Record['lastid'];
		if($id=="") { $id='0'; }
	    $id=$id + 1;
		
	 $db=new Database;
	 $insert="insert into locations values('$id','$x_value','$y_value')";
	 $db->query($insert);
	 $text_header="PdId,X,Y,Location";

				//writing on text file.......
				$filename="locations.txt";
				$dataString=$id.','.$x_value.','.$y_value.',"('.$y_value.','.$x_value.')"'."\n";
				$file = fopen($filename,"a");
				$dataString2 = $dataString. PHP_EOL;
				fwrite($file, $dataString2);
				fclose($file);
				//writing on text file end....
				
?>