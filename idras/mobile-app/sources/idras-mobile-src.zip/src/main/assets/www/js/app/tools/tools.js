///* 
// * To change this license header, choose License Headers in Project Properties.
// * To change this template file, choose Tools | Templates
// * and open the template in the editor.
// */
//
//function deviceCheck()
//{
//    if (navigator.userAgent.match(/(iPhone|iPod|iPad|Android|BlackBerry)/)) {
//        return true;
//    }
//    return false;
//}
//function checkConnection() {
//    if (deviceCheck())
//    {
//        var networkState = navigator.connection.type;
//        if (networkState === Connection.NONE) {
//            return false;
//        }
//    }
//    return true;
//}
//
//function exitFromApp()
//{
//    navigator.app.exitApp();
//}
//function alertDismissed() {
//    exitFromApp();
//}
//function nothing() {
//}
//function customAlert(message, callback, title, buttonName) {
//    if (deviceCheck())
//    {
//        navigator.notification.alert(
//                message, // message
//                callback, // callback
//                title, // title
//                buttonName                  // buttonName
//                );
//    }
//    else
//    {
//        alert(title + ": " + message);
//    }
//}
//
//function customPrompt(message, onPrompt, title, buttonName) {
//    navigator.notification.prompt(
//            message, // message
//            onPrompt, // callback to invoke
//            title, // title
//            buttonName, // buttonLabels
//            'input'                 // defaultText
//            );
//}
//
//$(document).ready(function () {
//    $(window).keydown(function (event) {
//        if (event.keyCode === 13) {
//            event.preventDefault();
//            return false;
//        }
//    });
//});
//
//function crntDateTime() {
//    var currentdate = new Date();
//    var datetime = currentdate.getFullYear() + "/"
//            + (currentdate.getMonth() + 1) + "/"
//            + currentdate.getDate() + " "
//            + currentdate.getHours() + ":"
//            + currentdate.getMinutes() + ":"
//            + currentdate.getSeconds();
//    return datetime;
//}
//
//function validateEmail(emailField) {
//    var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
//
//    if (emailField) {
//        if (reg.test(emailField) == false)
//        {
//            alert('Invalid Email Address');
//            return false;
//        }
//    }
//
//    return true;
//
//}