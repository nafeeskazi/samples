/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */













$(document).on('pageshow', '#HomePage', function () 
{
/*------------------------------------------------------------------------------*/

if (navigator.geolocation) 
{
  navigator.geolocation.getCurrentPosition(success, error);
} else 
{
  error('not supported');
}

//navigator.permissions.query({name: 'geolocation'}).then(function(status) {
//  console.log(status);
//  alert(status);
//});

function success(position) 
{
  var s = document.querySelector('#status');

  if (s.className == 'success') {
    // not sure why we're hitting this twice in FF, I think it's to do with a cached result coming back
    return;
  }

  s.innerHTML = "found you!";
  s.className = 'success';

  var mapcanvas = document.createElement('div');
  mapcanvas.id = 'mapcanvas';
  mapcanvas.style.height = '900px';
  mapcanvas.style.width = '600px';
  


  document.querySelector('article').appendChild(mapcanvas);

  var latlng = new google.maps.LatLng(position.coords.latitude, position.coords.longitude);
  
//  var latt = new google.maps.LatLng(position.coords.latitude);
//  var lngg = new google.maps.LatLng(position.coords.longitude);
  
//  alert(latlng);
  console.log(latlng);
  
//  console.log(latt);
//   alert(latt);
//   
//  console.log(lngg);
//   alert(lngg);
  
  SendCordinates(latlng);
  
  var myOptions = {
    zoom: 15,
    center: latlng,
    mapTypeControl: false,
    navigationControlOptions: {style: google.maps.NavigationControlStyle.SMALL},
    mapTypeId: google.maps.MapTypeId.ROADMAP
  };
  var map = new google.maps.Map(document.getElementById("mapcanvas"), myOptions);

  var marker = new google.maps.Marker({
      position: latlng,
      map: map,
      title:"You are here! (at least within a "+position.coords.accuracy+" meter radius)"
  });
}

/*------------------------------------------------------------------------------*/ 

/*------------------------------------------------------------------------------*/

function error(msg) 
{
  var s = document.querySelector('#status');
  s.innerHTML = typeof msg == 'string' ? msg : "failed";
  s.className = 'fail';

  // console.log(arguments);
}

/*------------------------------------------------------------------------------*/  
});







function myFunction() 
{

    $.mobile.changePage("#HomePage", {transition: "none", changeHash: false});  

}










/*==============================================================================*/



cordova.plugins.diagnostic.isLocationEnabled(function(enabled){
    console.log("Location is " + (enabled ? "enabled" : "disabled"));
    if(!enabled){
        cordova.plugins.diagnostic.switchToLocationSettings();
    }
}, function(error){
    console.error("The following error occurred: "+error);
});




function onRequestSuccess(success){
    console.log("Successfully requested accuracy: "+success.message);
}

function onRequestFailure(error){
    console.error("Accuracy request failed: error code="+error.code+"; error message="+error.message);
    if(error.code !== cordova.plugins.locationAccuracy.ERROR_USER_DISAGREED){
        if(window.confirm("Failed to automatically set Location Mode to 'High Accuracy'. Would you like to switch to the Location Settings page and do this manually?")){
            cordova.plugins.diagnostic.switchToLocationSettings();
        }
    }
}

cordova.plugins.locationAccuracy.request(onRequestSuccess, onRequestFailure, cordova.plugins.locationAccuracy.REQUEST_PRIORITY_HIGH_ACCURACY);

