///* 
// * To change this license header, choose License Headers in Project Properties.
// * To change this template file, choose Tools | Templates
// * and open the template in the editor.
// */
//var temp = { fp:null};
//function filedisplay(Folder_Name) {
//
////step to request a file system 
//    window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, fileSystemSuccess, fileSystemFail);
//
//    var fp;
//    function fileSystemSuccess(fileSystem) {
//
//        var directoryEntry = fileSystem.root; // to get root path of directory
//        var rootdir = fileSystem.root;
//        fp = rootdir.toURL();  // Returns Fulpath of local directory
//
//        fp = fp + "/" + Folder_Name + "/"; // fullpath and name of the file which we want to give
//       // localStorage.setItem('fpath', fp);
//       temp.fp = fp;
//    }
//
//    function fileSystemFail(evt) {
//        //Unable to access file system
//        alert(evt.target.error.code);
//    }
//}
//
//function removeFolder(Folder_Name) {
//
////step to request a file system 
//    window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, fileSystemSuccess, fileSystemFail);
//
//    var fp;
//    function fileSystemSuccess(fileSystem) {
//
//        var directoryEntry = fileSystem.root; // to get root path of directory
//        var rootdir = fileSystem.root;
//        fp = rootdir.toURL();  // Returns Fulpath of local directory
//
//        fp = fp + "/" + Folder_Name + "/"; // fullpath and name of the file which we want to give
//        fileSystem.root.getDirectory(
//                 Folder_Name,
//                {create : true, exclusive : false},
//                function(entry) {
//                entry.removeRecursively(function() {
//                    console.log("Remove Recursively Succeeded");
//                }, fileSystemFail);
//            }, fileSystemFail);
//    }
//
//    function fileSystemFail(evt) {
//        //Unable to access file system
//        alert(evt.target.error.code);
//    }
//}
//
//var removeByAttr = function (arr, attr, value) {
//    var i = arr.length;
//    while (i--) {
//        if (arr[i]
//                && arr[i].hasOwnProperty(attr)
//                && (arguments.length > 2 && arr[i][attr] === value)) {
//
//            arr.splice(i, 1);
//
//        }
//    }
//    return arr;
//};
//
//function onConfirm(buttonIndex) {
//    switch (buttonIndex) {   
//    case 1:
//        exitFromApp();
//        break;
//    case 2:
//        break;
//    }
//}
//
//function onBackKeyDown() {  
//    navigator.notification.confirm(
//        'Do you really want to Exit?',  // message
//        onConfirm,                  // callback to invoke
//        'Menu',            // title
//        ['Exit','Cancel']            // buttonLabels                      // defaultText
//    );   
//}
//
//var MyPopUp = false;
//function onMenuKeyPress() 
//{
//    if (MyPopUp && !MyPopUp.closed)
//    {
//        $('#popupMenu').popup('close');
//        MyPopUp = false;
//    }
//    else
//    {
//        MyPopUp = $('#popupMenu').popup('open', {transition: 'slideup', positionTo: '#settings'});
//    }
//}
//
