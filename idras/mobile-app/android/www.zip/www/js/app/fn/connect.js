/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


      

/*--------------------------- Cube Building Details List --------------------=======================================*/


function SendCordinates(latlng) 
{
      var webservice = "http://cryptopayglobal.com/webservice/store_co_ordinates.php";
                 
    console.log(webservice);
    console.log(latlng);

    var postData = '{"x_y_value":"' + latlng+'"}';

    console.log(postData);

    $.ajax
    ({
      
        async: true,
        type: "POST",
        contentType: "application/json ; charset=utf-8",
        url: webservice,
        dataType: "json",
        jsonp: "callback",
        data: postData, 
       
        success: function(data) 
        {           
            ajax.parseJSONP(data);  
            console.log(data);
        }       
    });
}
/*------------------------------------------------------------------------------*/
/*-------------------- All Market Order Information from WebServer -------------*/

var ajax = 
{
    parseJSONP: function (data) 
    {    
        
        Info.Companies = data.Companies;
        localStorage.setItem('Companies', JSON.stringify(data.Companies));      
        console.log(Info.Companies);
        console.log(Info.Companies);       
        
    }     
};
/*------------------------------------------------------------------------------*/
